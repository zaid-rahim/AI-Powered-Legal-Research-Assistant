#!/usr/bin/env python3
"""
Regex-based entity extractor for criminal judgments.
Now detects all case number variants (e.g., Criminal Appeal No.52-P/2009,
Criminal Appeals No. 386, 387, 388, 389 and 390 of 2018, etc.)
and captures the *entire line* containing them.
"""

import os
import re
import json

# === Base Paths ===
BASE_DIR = os.getcwd()
TEXT_FOLDERS = ["100cases_texts"]  # Add more folders if needed

# === Regex Patterns ===
PATTERNS = {
    # --- Case Number (captures entire line) ---
    "case_no": re.compile(
        r"(?i)(.*civil|criminal\s+(?:appeal|appeals|petition|petitions|Revision)[^\n]*)"
    ),

    # --- Judges ---
    "judges": re.compile(
        r"(?:hon'?ble\s+mr\.?\s+justice\s+|justice\s+|before\s)([a-z][a-z\s\.\-]+?)(?=,\s*J\.)",
        re.IGNORECASE
    ),


    # --- Parties ---
    "petitioner": re.compile(r"(?i)(appellant|petitioner)\s*[:\-]?\s*([a-z][a-z\s\.]+)"),
    "respondent": re.compile(r"(?i)(respondent)\s*[:\-]?\s*([a-z][a-z\s\.]+)"),

    # --- Lawyers ---
    "lawyers": re.compile(
        r"(?i)(for the (?:appellant|petitioner|respondent)[^:]*:\s*(?:mr\.|ms\.)\s*[a-z][a-z\s\.]+)"
    ),

    # --- Decision Summary ---
    "decision": re.compile(r"(?i)(appeal|petition)[^\.]*(allowed|dismissed|granted|rejected)"),

    # --- Decision Date ---
    "date": re.compile(r"\b\d{1,2}[./-]\d{1,2}[./-]\d{4}\b"),

    # --- Law Sections ---
    "law_section": re.compile(r"(?i)section\s*\d+\s*[a-z]*\s*(?:ppc|crpc|constitution)?"),

    # --- Courts ---
    "court": re.compile(
        r"(?i)(supreme court|high court|peshawar high court|lahore high court|sindh high court|balochistan high court|islamabad high court|session court|peshawar|islamabad|lahore|sindh|balochistan)"
    ),
}

# === Helper Functions ===
def clean_text_case(s):
    """Normalize capitalization while preserving acronyms (e.g., PPC, CrPC)."""
    s = s.strip()
    if not s:
        return s
    s = s.lower()
    s = re.sub(r"\b([a-z])", lambda m: m.group(1).upper(), s)  # capitalize first letters
    s = re.sub(r"\b(Ppc|Crpc|Fia|Nab|FIR|Constitution)\b", lambda m: m.group(1).upper(), s)
    return s

def extract_entities(text):
    """Apply regex patterns (case-insensitive) and return structured entities."""
    text_lower = text.lower()
    entities = {}

    # Capture full line with "Criminal Appeal" or "Criminal Petition"
    case_matches = PATTERNS["case_no"].findall(text)
    if case_matches:
        # Take the first matching line and clean it
        entities["case_no"] = clean_text_case(case_matches[0].strip())
    else:
        entities["case_no"] = "Unknown"

    # Judges
    judges = PATTERNS["judges"].findall(text_lower)
    entities["judges"] = [clean_text_case(j) for j in judges]

    # Petitioner / Respondent
    pet = PATTERNS["petitioner"].search(text_lower)
    entities["petitioner"] = clean_text_case(pet.group(2)) if pet else "Unknown"

    resp = PATTERNS["respondent"].search(text_lower)
    entities["respondent"] = clean_text_case(resp.group(2)) if resp else "Unknown"

    # Lawyers
    lawyers = [clean_text_case(l.split(":")[-1]) for l in PATTERNS["lawyers"].findall(text_lower)]
    entities["lawyers"] = lawyers

    # Law Sections
    laws = [clean_text_case(l) for l in PATTERNS["law_section"].findall(text_lower)]
    entities["law_sections"] = list(set(laws)) if laws else []

    # Court
    court_match = PATTERNS["court"].search(text_lower)
    entities["court"] = clean_text_case(court_match.group(1)) if court_match else "Unknown"

    # Decision Summary
    decision = PATTERNS["decision"].search(text_lower)
    entities["decision_summary"] = clean_text_case(decision.group(0)) if decision else "Unknown"

    # Date
    date_match = PATTERNS["date"].search(text_lower)
    entities["decision_date"] = date_match.group(0) if date_match else "Unknown"

    return entities


# === Process All Files ===
all_results = []

for folder in TEXT_FOLDERS:
    folder_path = os.path.join(BASE_DIR, folder)
    if not os.path.isdir(folder_path):
        print(f"⚠️ Folder not found: {folder}")
        continue

    for file in os.listdir(folder_path):
        if file.endswith(".txt"):
            file_path = os.path.join(folder_path, file)
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
                info = extract_entities(text)
                info["source_file"] = file
                info["case_type"] = "Civil"
                all_results.append(info)
                print(f"✅ Processed: {file} → {info['case_no']}")

# === Save Output ===
output_path = os.path.join(BASE_DIR, "regex_extracted_entities100_cases.json")
with open(output_path, "w", encoding="utf-8") as out:
    json.dump(all_results, out, indent=4, ensure_ascii=False)

print(f"\n🎯 Extraction complete! Saved structured data to:\n{output_path}")
