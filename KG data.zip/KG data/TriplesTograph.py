from neo4j import GraphDatabase
import json
import os

# === CONFIG ===
NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "fast123!"  # change this!

BASE_DIR = os.getcwd()
TRIPLE_FILE = os.path.join(BASE_DIR, "case_triples.json")

# === CONNECT TO NEO4J ===
driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

def create_triple(tx, subj, pred, obj):
    """Create nodes and relation for one triple"""
    query = f"""
    MERGE (a:Entity {{name: $subj}})
    MERGE (b:Entity {{name: $obj}})
    MERGE (a)-[:{pred}]->(b)
    """
    tx.run(query, subj=subj, obj=obj)

with open(TRIPLE_FILE, "r", encoding="utf-8") as f:
    triples = json.load(f)

with driver.session() as session:
    for subj, pred, obj in triples:
        try:
            session.execute_write(create_triple, subj, pred, obj)
            print(f"✅ Added: ({subj}) -[{pred}]-> ({obj})")
        except Exception as e:
            print(f"⚠️ Failed for {subj}-{pred}-{obj}: {e}")

driver.close()
print("\n🎯 Import complete! Check Neo4j browser at http://localhost:7687")
