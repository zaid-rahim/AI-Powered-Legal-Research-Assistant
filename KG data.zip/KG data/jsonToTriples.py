import json
import os

# === Load Extracted Entities ===
BASE_DIR = os.getcwd()
input_file = os.path.join(BASE_DIR, "regex_extracted_entities100_cases.json")

with open(input_file, "r", encoding="utf-8") as f:
    cases = json.load(f)

triples = []

for case in cases:
    case_id = case.get("case_no", "Unknown").replace(" ", "_")

    # --- Judges ---
    for judge in case.get("judges", []):
        triples.append((case_id, "hasJudge", judge))

    # --- Petitioner / Appellant ---
    if case.get("petitioner") != "Unknown":
        triples.append((case_id, "hasPetitioner", case["petitioner"]))

    # --- Respondent ---
    if case.get("respondent") != "Unknown":
        triples.append((case_id, "hasRespondent", case["respondent"]))

    # --- Court ---
    if case.get("court") != "Unknown":
        triples.append((case_id, "decidedIn", case["court"]))

    # --- Decision ---
    if case.get("decision_summary") != "Unknown":
        triples.append((case_id, "decision", case["decision_summary"]))

    # --- Law Sections ---
    for law in case.get("law_sections", []):
        triples.append((case_id, "refersToLaw", law))

# === Save Output ===
output_file = os.path.join(BASE_DIR, "case_triples_100_cases.json")

with open(output_file, "w", encoding="utf-8") as out:
    json.dump(triples, out, indent=4, ensure_ascii=False)

print(f"✅ {len(triples)} triples generated and saved to {output_file}")
