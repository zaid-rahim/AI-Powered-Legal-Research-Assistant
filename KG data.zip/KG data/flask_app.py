from flask import Flask, render_template, request
from py2neo import Graph
from pyvis.network import Network
import os
import re

app = Flask(__name__)

# --- Neo4j connection ---
graph_db = Graph("bolt://localhost:7687", auth=("neo4j", "fast123!"))

# -------------------------------------
# CLEAN NAME UTILS
# -------------------------------------
def clean_name(name):
    if not name:
        return "Unknown"

    name = name.split("\n")[0].strip()
    name = re.sub(r'[_\s]+', ' ', name)   # remove underscores
    return name


# -------------------------------------
# HUMAN READABLE RELATION MAPPING
# -------------------------------------
def format_relation(rel):
    mapping = {
        "hasJudge": "has Judge",
        "hasPetitioner": "has Petitioner",
        "hasRespondent": "has Respondent",
        "decidedIn": "was decided in",
        "decision": "decision:",
        "refersToLaw": "refers to law"
    }
    return mapping.get(rel, rel.replace("_", " ").title())


# -------------------------------------
# HOME PAGE
# -------------------------------------
@app.route('/')
def home():
    return render_template("search.html")

# -------------------------------------
# SEARCH LOGIC
# -------------------------------------
@app.route('/search')
def search():
    query_input = request.args.get('query')

    if not query_input:
        return render_template("search.html", query="", no_result=True)

    # Neo4j search query
    query = f"""
        MATCH (a)-[r]->(b)
        WHERE toLower(a.name) CONTAINS toLower('{query_input}')
           OR toLower(b.name) CONTAINS toLower('{query_input}')
           OR toLower(type(r)) CONTAINS toLower('{query_input}')
        RETURN a, r, b
    """

    data = graph_db.run(query).data()

    if not data:
        return render_template("search.html", query=query_input, no_result=True)

    # Convert to readable summary
    summary = []
    for record in data:
        a = clean_name(record["a"]["name"])
        b = clean_name(record["b"]["name"])
        r = type(record["r"]).__name__

        readable_r = format_relation(r)
        summary.append(f"{a} {readable_r} {b}")

    # Send summary + query back to search page
    return render_template(
        "search.html",
        results=summary,
        query=query_input,
        no_result=False,
        show_graph_button=True
    )

# -------------------------------------
# GRAPH VISUALIZATION PAGE
# -------------------------------------
@app.route('/graph')
def graph():
    query_input = request.args.get('query')

    query = f"""
        MATCH (a)-[r]->(b)
        WHERE toLower(a.name) CONTAINS toLower('{query_input}')
        RETURN a, r, b
    """

    data = graph_db.run(query).data()

    # Build graph
    net = Network(height="700px", width="100%", bgcolor="#222222", font_color="white")
    added_nodes = set()

    for record in data:
        a = clean_name(record["a"]["name"])
        b = clean_name(record["b"]["name"])
        r = format_relation(type(record["r"]).__name__)

        if a not in added_nodes:
            net.add_node(a, label=a, color="orange")
            added_nodes.add(a)

        if b not in added_nodes:
            net.add_node(b, label=b, color="lightblue")
            added_nodes.add(b)

        net.add_edge(a, b, title=r)

    # Save graph
    net.save_graph("graph.html")
    return render_template("graph.html", query=query_input)


# -------------------------------------
# RUN APP
# -------------------------------------
if __name__ == '__main__':
    app.run(debug=True)
